import 'package:flutter_test/flutter_test.dart';
import 'package:smart_calculator/core/strings.dart';

void main() {
  test('every text exists in English and Khmer', () {
    final en = S.table['en']!.keys.toSet();
    final km = S.table['km']!.keys.toSet();
    expect(km.difference(en), isEmpty);
    expect(en.difference(km), isEmpty);
  });

  test('placeholders are filled', () {
    expect(S.of('en', 'sharesLeft', {'n': 2, 'max': 3}), '2 of 3 free shares left today');
  });
}
