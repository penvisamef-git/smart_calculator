import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:hive_ce/hive.dart';

import '../core/constants.dart';
import '../models/history_item.dart';

/// Saved calculations. Newest first.
class HistoryRepository extends ChangeNotifier {
  HistoryRepository(this._box) {
    _items = _box.values.map(HistoryItem.fromMap).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  final Box<Map> _box;
  late List<HistoryItem> _items;
  final _rand = Random();

  List<HistoryItem> get items => List.unmodifiable(_items);
  int get count => _items.length;

  HistoryItem? byId(String id) {
    for (final i in _items) {
      if (i.id == id) return i;
    }
    return null;
  }

  HistoryItem add(String expression, double result) {
    final item = HistoryItem(
      id: '${DateTime.now().microsecondsSinceEpoch}${_rand.nextInt(999)}',
      expression: expression,
      result: result,
      createdAt: DateTime.now(),
    );
    _items.insert(0, item);
    _box.put(item.id, item.toMap());
    notifyListeners();
    return item;
  }

  void rename(String id, String name) {
    final item = byId(id);
    if (item == null) return;
    item.name = name.trim();
    _box.put(id, item.toMap());
    notifyListeners();
  }

  void delete(String id) {
    _items.removeWhere((i) => i.id == id);
    _box.delete(id);
    notifyListeners();
  }

  /// Puts a deleted item back (for "Undo").
  void restore(HistoryItem item) {
    _items
      ..add(item)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    _box.put(item.id, item.toMap());
    notifyListeners();
  }

  Future<void> deleteAll() async {
    _items.clear();
    await _box.clear();
    notifyListeners();
  }

  /// Free plan: remove items older than 30 days. Called at start-up.
  void purgeExpired({required bool isPremium, DateTime? now}) {
    if (isPremium) return;
    final cutoff = (now ?? DateTime.now())
        .subtract(const Duration(days: AppConfig.freeHistoryDays));
    final old = _items.where((i) => i.createdAt.isBefore(cutoff)).toList();
    if (old.isEmpty) return;
    for (final i in old) {
      _box.delete(i.id);
    }
    _items.removeWhere((i) => i.createdAt.isBefore(cutoff));
    notifyListeners();
  }

  /// Days until the oldest item is removed on the free plan (null if empty).
  int? daysUntilOldestExpires({DateTime? now}) {
    if (_items.isEmpty) return null;
    final oldest = _items.last.createdAt;
    final expires = oldest.add(const Duration(days: AppConfig.freeHistoryDays));
    final d = expires.difference(now ?? DateTime.now()).inHours / 24;
    return max(0, d.ceil());
  }

  List<HistoryItem> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return items;
    final digits = q.replaceAll(',', '');
    return _items.where((i) {
      return i.name.toLowerCase().contains(q) ||
          i.expression.contains(digits) ||
          i.prettyResult.replaceAll(',', '').contains(digits);
    }).toList();
  }
}
