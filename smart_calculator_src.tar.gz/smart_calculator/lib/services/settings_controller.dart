import 'package:flutter/material.dart';
import 'package:hive_ce/hive.dart';

import '../core/app_theme.dart';

/// User settings: theme, language, vibration, live result.
class SettingsController extends ChangeNotifier {
  SettingsController(this._box) {
    _themeId = _box.get('themeId', defaultValue: AppThemes.cyberTeal.id) as String;
    final accent = _box.get('customAccent') as int?;
    _customAccent = accent == null ? null : Color(accent);
    _language = _box.get('language', defaultValue: _deviceLanguage()) as String;
    _vibration = _box.get('vibration', defaultValue: true) as bool;
    _liveResult = _box.get('liveResult', defaultValue: true) as bool;
  }

  final Box _box;

  late String _themeId;
  Color? _customAccent;
  late String _language;
  late bool _vibration;
  late bool _liveResult;

  String get themeId => _themeId;
  Color? get customAccent => _customAccent;
  String get language => _language;
  bool get vibration => _vibration;
  bool get liveResult => _liveResult;

  /// The palette in use. Premium themes / custom accent fall back to the
  /// default theme if the user is not Premium (e.g. after a refund).
  AppPalette palette({required bool isPremium}) {
    var p = AppThemes.byId(_themeId);
    if (p.premium && !isPremium) p = AppThemes.cyberTeal;
    if (_customAccent != null && isPremium) p = p.withAccent(_customAccent!);
    return p;
  }

  Locale get locale => Locale(_language);

  void setTheme(String id, {Color? customAccent}) {
    _themeId = id;
    _customAccent = customAccent;
    _box.put('themeId', id);
    if (customAccent == null) {
      _box.delete('customAccent');
    } else {
      _box.put('customAccent', customAccent.toARGB32());
    }
    notifyListeners();
  }

  void setLanguage(String code) {
    _language = code;
    _box.put('language', code);
    notifyListeners();
  }

  void setVibration(bool v) {
    _vibration = v;
    _box.put('vibration', v);
    notifyListeners();
  }

  void setLiveResult(bool v) {
    _liveResult = v;
    _box.put('liveResult', v);
    notifyListeners();
  }

  static String _deviceLanguage() {
    final code = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    return code == 'km' ? 'km' : 'en';
  }
}
