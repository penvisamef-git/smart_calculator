import '../core/calc_engine.dart';

/// One saved calculation.
class HistoryItem {
  HistoryItem({
    required this.id,
    required this.expression,
    required this.result,
    required this.createdAt,
    this.name = '',
  });

  final String id;

  /// Raw expression as typed, e.g. `12500+8000×3`.
  final String expression;
  final double result;
  final DateTime createdAt;
  String name;

  bool get hasName => name.trim().isNotEmpty;
  String get prettyExpression => CalcEngine.pretty(expression);
  String get prettyResult => CalcEngine.formatNumber(result);

  /// `12,500 + 8,000 × 3 = 36,500`
  String get line => '$prettyExpression = $prettyResult';

  Map<String, dynamic> toMap() => {
        'id': id,
        'expression': expression,
        'result': result,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'name': name,
      };

  factory HistoryItem.fromMap(Map<dynamic, dynamic> m) => HistoryItem(
        id: m['id'] as String,
        expression: m['expression'] as String,
        result: (m['result'] as num).toDouble(),
        createdAt: DateTime.fromMillisecondsSinceEpoch(m['createdAt'] as int),
        name: (m['name'] as String?) ?? '',
      );
}
